export const MyInformation = [
  'Name(👨‍💻): Lương Quang Hùng',
  'Date of birth(🎉): 01/02/2003',
  'Gender(🧑/👩): Boy',
  'Address(💒): Binh Khuong Commune, Binh Son District, Quang Ngai Province',
  'Common Name(👉): Kudo Shinichi',
];
export const MyEducation = [
  'Trường Tiểu Học Vĩnh Phương(khánh hòa 1-2 ).',
  'Trường Tiểu Học Xã Bình Khương(Quảng Ngãi 3-5).',
  'Trường Trung Học Cơ Sở Bình Khương(Quảng Ngãi 6-9).',
  'Trường Cao Dẳng Kỹ Nghệ Dung Quất Và Trung Tâm Giáo Dục Thường Xuyên TP Quảng Ngãi(Quảng Ngãi 10-12 và Bảo Trì Cơ Khí).',
  'Trường Đại Học Dông Á (Đà Nẵng 2021-2025).',
  'Bằng Cấp: Trung Cấp Bảo Trì Cơ Khí và Kỹ Sư Phần Mềm.',
];
export const MyPreference = [
  'Thích Màu Sắt Sáng, Đặt Biệt Màu Đỏ.',
  'Thích Không Gian yên Tỉnh (Biển Núi).',
  'Thích Cây Cỏ Hoa Lá.',
  'Thích Những Thứ Mới Mẽ Và Kì Lạ.',
  'Thích Nghe Nhạc, Thích Hát, Thích Nhảy.',
  'Thích Làm Những Thứ Mình Thích.',
  'Thích Đi Đến Vùng Đất Mới Và Du Lịch.',
];
export const MySkills = [
  'Làm ViệC Nhóm',
  'Làm Thêm Nhiều Giờ',
  'Lãnh Đạo',
  'Dễ Làm Quen',
  'Biết Lập Trình Nodejs, JavaScript, Java, HTML, CSS, Python, C++..',
  'Biết Dùng Công Cụ Visual Studio Code, Android Studio,  IntelliJ IDEA, ...',
];
export const MyAchievements = [
  'Kỹ Sư Phần Mềm',
  'Chứng Chỉ Quốc tế Đại Học Hàng Quốc Koreatech ',
  'Chứng Chỉ Blockchan Banani',
  'Chứng Chỉ FreeCodeCam ',
];
export const MyExperience = [
  'Thực Tập Sinh Tại Công Ty Điện Lạnh Khang Phát (Sài Gòn 20.05.2024 - 22.07.2024).',
  '4 Năm Kinh Nghiệm Học Tại Đại Học Đông Á.',
  'Tham Gia Lớp Học Python Hàn Quốc.',
  'Tham Gia Các Sự Kiện Cùng Với Chuyên Gia Khác.',
];
export const MyContact = ['YouTuBe: ', 'GitHub: ', 'Facebook', 'In'];
export const MyProduct = [
  'Front End',
  'Back End',
  'Full Start',
  'Java',
  'Flutter',
  'Dart',
  'HTML',
  'JavaSrcipt',
];
