export const ListH2 = [
  'My information',
  'My preference',
  'My skills',
  'My education',
  'My achievements',
  'My experience',
  'My Contact',
  'My product',
];
export const ListP = [];
